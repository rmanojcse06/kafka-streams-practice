package edu.man.kafka.producer;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;

@Slf4j
@SpringBootApplication
public class MainApplication {
    public static void main(String[] args) {
        log.info("Hello, main application is started");
        AnnotationConfigApplicationContext context
                = new AnnotationConfigApplicationContext("edu.man.kafka.producer");
        context.registerShutdownHook();
    }

    @EventListener(ContextRefreshedEvent.class)
    public void runAfterStartup() {
        log.info("Running after application startup...");
    }
}