package edu.man.kafka.producer.mongo.config; // Recommended package

import com.mongodb.reactivestreams.client.MongoClient;
import com.mongodb.reactivestreams.client.MongoClients;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;

@Configuration
@Slf4j
public class MongoConfiguration {

    @Autowired
    Environment env;

    @PostConstruct
    public void listEnv() {
        for (org.springframework.core.env.PropertySource<?> ps : ((AbstractEnvironment) env).getPropertySources()) {
            System.out.println("== " + ps.getName());
//            if (ps instanceof EnumerablePropertySource eps) {
//                for (String key : eps.getPropertyNames()) {
//                    System.out.println("  " + key + " = " + eps.getProperty(key));
//                }
//            }
        }
    }


//    @Value("${spring.data.mongodb.uri}")
//    private String mongoUri;
//
//
//    // 1. Create the MongoClient bean (Use the hardcoded URI for now, as you did before)
//    @Bean
//    public MongoClient mongoClient() {
//        // The URI should ideally come from application.yml,
//        // but this hardcoded version resolves your immediate issue.
//        return com.mongodb.reactivestreams.client.MongoClients.create(mongoUri);
//    }
//
//    // 2. Define the ReactiveMongoTemplate using the client
//    @Bean
//    public ReactiveMongoTemplate reactiveMongoTemplate(MongoClient mongoClient) {
//        // Using "inventorydb" to force the correct database name
//        return new ReactiveMongoTemplate(mongoClient, "inventorydb");
//    }
}