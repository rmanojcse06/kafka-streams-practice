#!/bin/bash
# mongo-replica-set-init.sh

# 1. Execute the default Docker initialization scripts (user creation, etc.)
# This ensures that your mongo-init.js for user creation runs first.
/usr/local/bin/docker-entrypoint.sh "$@" &

# 2. Start mongod with the required replica set flags
/usr/bin/mongod --replSet rs0 --bind_ip_all &

# 3. Wait for the server to be ready (must wait for a few seconds)
sleep 15

# 4. Initialize the replica set using mongosh
echo "Attempting to initialize replica set rs0..."
mongosh --host localhost:27017 <<EOF
    rs.initiate({
        _id: "rs0",
        members: [
            { _id: 0, host: "localhost:27017" }
        ]
    }, { force: true });
EOF

echo "Replica set initialization complete."

# 5. Wait indefinitely to keep the container running
wait
