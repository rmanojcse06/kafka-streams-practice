// /mongo-init.js
// Initialize replica set
// rs_init.js content
use admin
// /mongo-init.js
// --- Admin DB authentication ---
db = db.getSiblingDB("admin");

print("✔ Creating application user...");

db.createUser({
  user: "inventorydba",
  pwd: "password",
  roles: [
    { role: "readWrite", db: "inventorydb" },
    { role: "dbAdmin", db: "inventorydb" }
  ]
});

// --- Application DB ---
appDb = db.getSiblingDB("inventorydb");
print("✔ Creating database and collections...");

appDb.createCollection("inventory");
print("✔ MongoDB initialization completed successfully.");
appDb.createCollection('brand');
appDb.brand.insertMany([
  { "type": "phone", "name": "Apple", "origin": "USA"},
  { "type": "phone", "name": "Samsung", "origin": "KOR"},
  { "type": "phone", "name": "Xiaomi", "origin": "CHN"},
  { "type": "phone", "name": "Huawei", "origin": "CHN"},
  { "type": "phone", "name": "OPPO", "origin": "CHN"},
  { "type": "phone", "name": "Vivo", "origin": "CHN"},
  { "type": "phone", "name": "OnePlus", "origin": "CHN"},
  { "type": "phone", "name": "Lenovo", "origin": "CHN"},
  { "type": "phone", "name": "Motorola", "origin": "USA"},
  { "type": "phone", "name": "Google (Pixel)", "origin": "USA"},
  { "type": "phone", "name": "Sony", "origin": "JPN"},
  { "type": "phone", "name": "LG", "origin": "KOR"},
  { "type": "phone", "name": "Nokia (HMD Global)", "origin": "FIN"},
  { "type": "phone", "name": "ASUS", "origin": "TWN"},
  { "type": "phone", "name": "HTC", "origin": "TWN"},
  { "type": "phone", "name": "Micromax", "origin": "IND"}
]);
appDb.createCollection('customer');
appDb.customer.insertMany([{"name":"manoj", "tel":"8122355373", "mail": "rmanojcse06@gmail.com"}]);